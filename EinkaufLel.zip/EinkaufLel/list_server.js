"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express = require("express"); // express bereitstellen
const fs = require('fs'); // Zugriff auf Dateisystem
class record {
    constructor(who, item, where, date, status) {
        this.id = ++record.id_neuGroß; // Vergabe einer eindeutigen id
        this.status = status;
        this.who = who;
        this.item = item;
        this.where = where;
        this.date = new Date(date);
        record.stack.push(this); // Der aktuelle record wird zur Sicherung auf den Stack gelegt
    }
    getID() {
        // Ermittlung der id des rufenden records
        return this.id;
    }
    getStatus() {
        // Ermittlung des Status des rufenden records
        return this.status;
    }
    setStatus(status) {
        // Setzen des Status des rufenden records
        this.status = status;
        return this.status;
    }
    static getrecordStack() {
        return record.stack;
    }
}
record.id_neuGroß = 0;
record.stack = [];
class shoppingList {
    // ein Element in diesem Stack enthalten
    constructor() {
        this.kiste = [];
        shoppingList.stack.push(this);
    }
    getRecord(id) {
        let lop_act = undefined;
        for (let i of this.kiste) {
            if (id === i.getID()) {
                lop_act = i;
            }
        }
        return lop_act;
    }
}
shoppingList.stack = []; // Stack aller LoPs (im vorliegenden Fall ist nur
class ListLog {
    constructor(who, item, where, date, status) {
        this.who = who;
        this.item = item;
        this.date = date;
        this.where = where;
        this.status = status;
    }
}
// ----------------------------------------------------------------------------
// Funktionen
function ListSave(loP, file) {
    // Sichern der übergebenen shoppingList in die Datei mit dem Pfad file.
    // Der gespeicherte JSON-String wird von der Funkion zurückgegeben
    // Aufbau des JSONs mit der shoppingList als Objekt der Klasse ListLog
    const logList = [];
    for (let i of current_List.kiste) {
        logList.push(new ListLog(i.who, i.item, i.where, i.date, i.getStatus()));
    }
    // Umwandeln des Objekts in einen JSON-String
    const logListJSON = JSON.stringify(logList);
    // Schreiben des JSON-Strings der shoppingList in die Datei mit dem Pfadnamen "file"
    fs.writeFile(file, logListJSON, (err) => {
        if (err)
            throw err;
        if (logRequest)
            console.log("shoppingList gesichert in der Datei: ", file);
    });
    return logListJSON;
}
function renderList(shoppingList) {
    // Aufbereitung der aktuellen shoppingList als HTML-tbody
    let html_List = "";
    for (let i in shoppingList.kiste) {
        // Ein Element der shoppingList wird nur ausgegeben, wenn sein Status auf aktiv (1) steht.
        if (shoppingList.kiste[i].getStatus() === 1) {
            let id = shoppingList.kiste[i].getID();
            let who = shoppingList.kiste[i].who;
            let item = shoppingList.kiste[i].item;
            let where = shoppingList.kiste[i].where;
            let date = shoppingList.kiste[i].date;
            console.log(date);
            let date_string = date.toISOString().slice(0, 10);
            console.log(date_string);
            html_List += "<tr class='b-dot-line' data-lop-id='" + id + "'>";
            html_List += "<td class='click-value' data-purpose='who' " +
                "data-lop-id='" + id + "'>" + who + "</td>";
            html_List += "<td class='click-value as-width-40pc' data-purpose='item' " +
                "data-lop-id='" + id + "'>" + item + "</td>";
            html_List += "<td class='click-value' data-purpose='where'" +
                " data-lop-id='" + id + "'>" + where + "</td>";
            html_List += "<td class='click-value' data-purpose='date'" +
                " data-lop-id='" + id + "'>" + date_string + "</td>";
            html_List += "<td class='click-value' data-lop-id='" + id + "'>" +
                "<input data-purpose='ändern' type = 'submit' value = 'E' class='as-button-0'  " +
                "data-lop-id = '" + id + "'>" +
                "<input type = 'submit' value = 'X' class='as-button-0' " +
                "data-purpose = 'loeschen' data-lop-id = '" + id + "'>" +
                "</td>";
            html_List += "</tr>";
        }
    }
    return html_List;
}
function renderListChange(listChange) {
    // Aufbereitung des aktuellen records für die Änderungs-/Löschausgabe in
    // der zugehörigen Tabellenzeile
    let id_act = listChange.getID();
    let who = listChange.who;
    let item = listChange.item;
    let where = listChange.where;
    let date = listChange.date;
    let html_Change = "";
    html_Change += "<td><input type='text' value='" + who + "'></td>" +
        "<td><input class='as-width-100pc' type='text' value='" +
        item + "'>" +
        "<br>" +
        " <form>" +
        "<input type = 'submit' value = 'ändern' class='as-button-0' " +
        "data-purpose = 'aendern' data-lop-id = '" + id_act + "'>" +
        "<input type = 'submit' value = 'zurück' class='as-button' " +
        "data-purpose = 'zurück' data-lop-id = '" + id_act + "'>" +
        "<input type = 'submit' value = 'löschen' class='as-button' " +
        "data-purpose = 'loeschen' data-lop-id = '" + id_act + "'>" +
        "</form>" +
        "</td>" +
        "<td><input type='text' value='" + where + "'>" +
        "</td>" +
        "<td><input type='text' value='" + date.toISOString().slice(0, 10) + "'>" +
        "</td>";
    return html_Change;
}
// Globale Variablen ----------------------------------------------------------
let programmname = "shoppingList";
let version = '';
let username; // aktuelle Bearbeiterperson
let current_List = new shoppingList(); // shoppingList anlegen
let listRunCounter = 0; // Anzahl der Serveraufrufe vom Client
// Debug Informationen über console.log ausgeben
const logRequest = true;
// ----------------------------------------------------------------------------
// Die aktuelle shoppingList wird bei jeder Änderung zur Sicherung und Wiederverwendung in
// einer Datei mit eindeutigem Dateinamen gespeichert.
const logRunDate = (new Date()).toISOString();
const logListFile_work = "log/logList.json";
const logListFile_save_pre = "log/logList_";
fs.readFile(logListFile_work, "utf-8", (err, lopData) => {
    // Einlesen der letzten aktuellen shoppingList -----------------------------------------
    if (err) {
        // Wenn die Datei nicht existiert, wird eine neue Liste angelegt
        current_List.kiste = [];
    }
    else {
        // Wenn die Datei existiert, werden die JSON-Daten eingelesen und es wird
        // die letzte aktuelle shoppingList rekonstruiert.
        const lopDataJSON = JSON.parse(lopData); // JSON aus den eingelesenen Daten
        for (let i of lopDataJSON) {
            // Aus dem JSON die shoppingList aufbauen
            current_List.kiste.push(new record(i.who, i.item, i.where, new Date(i.date), i.status));
        }
    }
    if (logRequest)
        console.log("shoppingList eingelesen. Anzahl der Einträge: ", current_List.kiste.length);
});
// ----------------------------------------------------------------------------
// Aktivierung des Servers
const server = express();
const serverPort = 8080;
const serverName = programmname + " " + version;
server.listen(serverPort);
console.log("Der Server \"" + serverName + "\" steht auf Port ", serverPort, "bereit", "\nServerstart: ", logRunDate);
server.use(express.urlencoded({ extended: false })); // URLencoded Auswertung ermöglichen
server.use(express.json()); // JSON Auswertung ermöglichen
// ----------------------------------------------------------------------------
// Mapping von Aliases auf reale Verzeichnisnamen im Dateisystem des Servers
// Basisverzeichnis des Webservers im Dateisystem
let rootDirectory = __dirname;
server.use("/style", express.static(rootDirectory + "/style"));
server.use("/script", express.static(rootDirectory + "/script"));
console.log("root directory: ", rootDirectory);
// ----------------------------------------------------------------------------
// Start der Website auf dem Client durch Übergabe der index.html -------------
server.get("/", (req, res) => {
    if (logRequest)
        console.log("GET /");
    res.status(200);
    res.sendFile(rootDirectory + "/html/index.html");
});
server.get("/favicon.ico", (req, res) => {
    // Hier wird das Icon für die Website ausgeliefert
    if (logRequest)
        console.log("GET favicon.ico");
    res.status(200);
    res.sendFile(rootDirectory + "/image/einkaufskorb-sticker.ico");
});
server.get("/version", (req, res) => {
    // Hier wird die Serverversion ausgeliefert
    if (logRequest)
        console.log("GET version");
    res.status(200);
    res.send(serverName);
});
// ----------------------------------------------------------------------------
// CREATE - Neuer record in die shoppingList
server.post("/create", (req, res) => {
    ++listRunCounter;
    // Wert vom Client aus dem JSON entnehmen
    const who = String(req.body.who);
    const item = String(req.body.item);
    const where = String(req.body.where);
    const date = new Date(req.body.date);
    username = who;
    if (logRequest)
        console.log("Post /create: ", listRunCounter);
    current_List.kiste.push(new record(who, item, where, date, 1));
    // Die aktuelle shoppingList wird gesichert und in einer
    // Datei gespeichert. Die Datei wird bei jeder Berechnung wieder
    // mit dem aktuellen Stand der shoppingList überschrieben.
    ListSave(current_List, logListFile_work);
    // Rendern der aktuellen shoppingList und Rückgabe des gerenderten Tabellenteils (tbody)
    const html_tbody = renderList(current_List);
    res.status(200);
    res.send(html_tbody);
});
// ----------------------------------------------------------------------------
// READ
server.get("/read", (req, res) => {
    // READ - Rückgabe der vollständigen shoppingList als HTML-tbody
    ++listRunCounter;
    const currentListLength = current_List.kiste.length;
    if (logRequest)
        console.log("GET /read: ", listRunCounter, currentListLength);
    if (current_List === undefined) {
        res.status(404);
        res.send("shoppingList does not exist");
    }
    else {
        // Rendern der aktuellen shoppingList
        const html_tbody = renderList(current_List);
        res.status(200);
        res.send(html_tbody);
    }
});
server.post("/read", (req, res) => {
    // READ -Rückgabe der Tabellenzeile für ändern und löschen
    ++listRunCounter;
    // Wert vom Client aus dem JSON entnehmen
    const id_act = Number(req.body.id_act);
    const listChange = current_List.getRecord(id_act);
    if (logRequest)
        console.log("Post /read: ", listRunCounter, id_act, listChange);
    if (current_List === undefined || listChange.getStatus() !== 1) {
        res.status(404);
        res.send("Item " + id_act + " does not exist");
    }
    else {
        // Rendern der aktuellen shoppingList
        const html_change = renderListChange(listChange);
        res.status(200);
        res.send(html_change);
    }
});
// ----------------------------------------------------------------------------
// UPDATE - shoppingList-record ändern
server.post("/update", (req, res) => {
    // Werte vom Client aus dem JSON entnehmen
    ++listRunCounter;
    const id_act = Number(req.body.id_act);
    const who = String(req.body.who);
    const item = String(req.body.item);
    const where = String(req.body.where);
    const date = new Date(req.body.date);
    if (logRequest)
        console.log("GET /update: ", listRunCounter, id_act);
    const listUpdate = current_List.getRecord(id_act);
    if (listUpdate === undefined || listUpdate.getStatus() !== 1) {
        res.status(404);
        res.send("Item " + id_act + " does not exist");
    }
    else {
        listUpdate.who = who;
        listUpdate.item = item;
        listUpdate.where = where;
        listUpdate.date = date;
        // Sichern der aktuellen shoppingList in die Datei logListFile_work
        ListSave(current_List, logListFile_work);
        // Rendern der aktuellen shoppingList
        renderList(current_List);
        res.status(200);
        res.send("Item " + id_act + " changed");
    }
});
// ----------------------------------------------------------------------------
// DELETE - shoppingList-record aus der Liste löschen
server.post("/delete", (req, res) => {
    // Wert vom Client aus dem JSON entnehmen
    ++listRunCounter;
    const id_act = Number(req.body.id_act);
    const listDelete = current_List.getRecord(id_act);
    if (logRequest)
        console.log("Post /delete: ", listRunCounter, id_act, listDelete);
    if (listDelete === undefined || listDelete.getStatus() !== 1) {
        res.status(404);
        res.send("Item " + id_act + " does not exist");
    }
    else {
        listDelete.setStatus(2);
        // Sichern der aktuellen shoppingList in die Datei logListFile_work
        ListSave(current_List, logListFile_work);
        // Rendern der aktuellen shoppingList und Rückgabe des gerenderten Tabellenteils (tbody)
        //        const html_tbody = renderList(current_List)
        res.status(200);
        res.send("Item " + id_act + " deleted");
    }
});
// ----------------------------------------------------------------------------
// SAVE - shoppingList in Datei mit Datumstempel sichern
server.get("/save", (req, res) => {
    /* Die aktuelle shoppingList wird zur Sicherung und Wiederverwendung in einer Datei
       mit eindeutigem Dateinamen mit dem aktuellen Datumsstempel gespeichert.
     */
    ++listRunCounter;
    if (logRequest)
        console.log("Get /save: ", listRunCounter);
    const logDate = (new Date()).toISOString();
    let logDateFix = logDate.split(":").join("_");
    const logListFile_save = logListFile_save_pre + logDateFix + ".json";
    // Sichern der aktuellen shoppingList in die Datei logListFile_save
    ListSave(current_List, logListFile_save);
    res.status(200);
    res.send("shoppingList saved");
});
// ----------------------------------------------------------------------------
server.use((req, res) => {
    // Es gibt keine reguläre Methode im Server für die Beantwortung des Requests
    ++listRunCounter;
    if (logRequest)
        console.log("Fehler 404", req.url);
    res.status(404);
    res.set('content-type', 'text/plain; charset=utf-8');
    const urlAnfrage = req.url;
    res.send(urlAnfrage +
        "\n\nDie gewünschte Anfrage kann vom Webserver \"" + serverName +
        "\" nicht bearbeitet werden!");
});
//# sourceMappingURL=list_server.js.map