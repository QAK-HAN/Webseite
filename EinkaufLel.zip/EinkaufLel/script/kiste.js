// Globale Variablen ----------------------------------------------------------
let serviceName;
let statusCreate = 0; // Status des Eingabemodus: 0 = offen, 1 = eingeben, 2 = ändern
let username; // aktuelle Bearbeiterperson
// Debug Informationen über console.log ausgeben
let logEvent = true; // Ausgabe der Event-Starts in console.log
let logEventFull = false; // Ausgabe der vollständigen Events in console.log
// Funktionen -----------------------------------------------------------------
function start() {
    /* Start der Website */
    // Programmversion vom Server beziehen
    // XMLHttpRequest aufsetzen und absenden
    const request = new XMLHttpRequest();
    // Request starten
    request.open('GET', 'version');
    request.send();
    request.onload = (event) => {
        // Eventhandler das Lesen der aktuellen Tabelle vom Server
        if (request.status === 200) { // Erfolgreiche Rückgabe
            serviceName = request.response;
            // Version eintragen
            document.getElementById("version-title").innerText = serviceName;
            document.getElementById("version").innerText = serviceName;
            console.log(serviceName);
        }
        else { // Fehlermeldung vom Server
            console.log("Fehler bei der Übertragung", request.status);
            if (logEvent)
                console.log("Fehler bei der Übertragung", request.status, "\n", event);
        }
    };
}
function basedata(event) {
    /* Aufbau der Tabelle nach der Eingabe des Bearbeiters
     */
    event.preventDefault();
    username = document.getElementById("user-name").value;
    if (logEvent)
        console.log("Basisdaten: ", username); // Debug
    // Freigabe der LoP-Ausgabe im HTML-Dokument
    const shoppingList = document.getElementById("shopping-list");
    shoppingList.classList.remove("as-unsichtbar");
    shoppingList.classList.add("as-sichtbar");
    // Lesen der aktuellen Tabelle vom Server und Ausgabe in list-tbody
    renderList();
}
function item(event) {
    /*
    * Abfragefenster für das Erzeugen (Create) eines neuen Eintrags in der LoP
    * */
    event.preventDefault();
    const command = event.submitter.value;
    if (command === "neu") {
        if (logEvent)
            console.log("function item -> new"); // Debug
        if (statusCreate === 0) {
            statusCreate = 1; // Der Status 1 sperrt die Bearbeitung anderer Events
            const tbody = document.getElementById("list-tbody");
            const html = tbody.innerHTML; // aktuellen Tabelleninhalt sichern
            const dateNew = (new Date()).toISOString().slice(0, 10); //aktuelles date bestimmen
            // Aufbau und Ausgabe der Eingabefelder für ein neues Element der LoP
            // Die Eingabefelder werden in der ersten Zeile der Tabelle angelegt
            const get_item = "<tr class='b-dot-line' data-lop-id='" + undefined + "'> " +
                "<td data-purpose='who' data-lop-id='" + undefined + "'>" +
                "<input name='who' type='text' data-lop-id='" + undefined +
                "' value = " + username + ">" +
                "</td>" +
                "<td data-purpose='item' data-lop-id='" + undefined + "'>" +
                " <form>" +
                "<input name = 'Aufgabe' type = 'text'  " +
                "placeholder = 'Aufgabe'  class= 'as-width-100pc' data-input ='item'>" +
                "<br>" +
                "<input type = 'submit' value = 'speichern' class='as-button-0' " +
                "data-purpose = 'speichern' data-lop-id = 'undefinded'>" +
                "<input type = 'submit' value = 'zurück' class='as-button' " +
                "data-purpose = 'zurück' data-lop-id = 'undefinded'>" +
                "</form>" +
                "</td>" +
                "<td data-purpose='where' data-lop-id='" + undefined + "'>" +
                "<input name = 'where' type = 'text'  " +
                "placeholder = 'where'  class= 'as-width-100pc' data-input ='where'></td>" +
                "<td data-purpose='date' data-lop-id='" + undefined + "'>" +
                "<input  name='date' type='text' " +
                "data-lop-id='" + undefined + "' data-purpose='date'" +
                "' value = " + dateNew + ">" +
                "</td>" +
                "</tr>";
            tbody.innerHTML = get_item + html;
        }
    }
    else if (command === "sichern") {
        /* Die Funktion "sichern" ist noch nicht implementiert.
           Es erfolgt in der vorliegenden Version nur eine Ausgabe der vollständigen Liste
           als JSON in die console.log.
         */
        if (logEvent)
            console.log("function item -> sichern"); // Debug
        // XMLHttpRequest aufsetzen und absenden
        const request = new XMLHttpRequest();
        // Request starten
        request.open('GET', 'save');
        request.send();
        request.onload = (event) => {
            // Eventhandler für das Lesen der aktuellen Tabellenzeile zum Ändern oder Löschen
            // vom Server
            if (request.status === 200) { // Erfolgreiche Rückgabe
                if (logEventFull)
                    console.log("Daten gesichert");
                renderList();
            }
            else { // Fehlermeldung vom Server
                console.log("Fehler bei der Übertragung", request.status);
                if (logEvent)
                    console.log("Fehler bei der Übertragung", request.status, "\n", event);
            }
        };
    }
    else {
        // Click ins Nirgendwhere
        if (logEvent)
            console.log("function item -> ?"); // Debug
    }
}
function createUpdateDelete(event) {
    /*
    * Create, Update und Delete von Einträgen in der LoP
    */
    event.preventDefault();
    if (logEvent)
        console.log("createUpdateDelete -> list-tbody; click"); // Debug
    if (logEventFull)
        console.log("\"createUpdateDelete -> list-tbody; click", event); // Debug
    const command = event.target.getAttribute("data-purpose");
    const idSelect = event.target.getAttribute("data-lop-id");
    if (logEvent)
        console.log("command: ", command, "id: ", idSelect); // Debug
    if (command === "zurück") {
        // zurück -------------------------------------------------------------------------------------
        // Rückkehr aus dem aktuellen Abfragefenster ohne Änderung
        if (logEvent)
            console.log("function  createUpdateDelete -> zurück"); // Debug
        renderList();
    }
    else if (command === "speichern") {
        // speichern ------------------------------------------------------------------------------
        // Erzeugen (Create) eines neuen Eintrags in der LoP
        if (logEvent)
            console.log("function  createUpdateDelete -> speichern"); // Debug
        if (statusCreate === 1) {
            const current_task = event.target.parentElement[0].value;
            if (current_task === "") {
                // Wenn keine Aufgabe angegeben wurde, wird die Erzeugung des Eintrags abgebrochen.
                renderList();
            }
            else {
                // Entnehmen der Daten für den neuen Eintrag aus dem HTML-Dokument
                const td_actual = event.target.parentElement.parentElement;
                const current_who = td_actual.previousSibling.childNodes[0].value;
                const current_where = td_actual.nextSibling.childNodes[0].value;
                const current_date = td_actual.nextSibling.nextSibling.childNodes[0].value;
                if (logEvent)
                    console.log("eingabe_aktuell: ", current_who, current_task, current_where, current_date); // Debug
                // Übertragen der neuen Aufgabe an den Server ---------------------------
                // XMLHttpRequest aufsetzen und absenden
                const request = new XMLHttpRequest();
                // Request starten
                request.open('POST', 'create');
                request.setRequestHeader('Content-Type', 'application/json');
                request.send(JSON.stringify({
                    "who": current_who,
                    "item": current_task,
                    "where": current_where,
                    "date": current_date,
                    "status": 1
                }));
                request.onload = (event) => {
                    // Eventhandler das Lesen der aktuellen Tabelle vom Server
                    if (request.status === 200) { // Erfolgreiche Rückgabe
                        renderList();
                    }
                    else { // Fehlermeldung vom Server
                        console.log("Fehler bei der Übertragung", request.status);
                        if (logEvent)
                            console.log("Fehler bei der Übertragung", request.status, "\n", event);
                    }
                };
                renderList();
            }
        }
    }
    else if (command === "who" || command === "item" || command === "where" || command === "date" || command === "ändern") {
        // Ändern aktivieren ----------------------------------------------------------------------
        // Ausgabe der Eingabefelder für die Änderung (Update) eines LoP-Eintrags
        if (logEvent)
            console.log("function  createUpdateDelete -> who, item, date"); // Debug
        if (logEvent)
            console.log("update: ", event.target.parentElement); // Debug
        if (statusCreate === 0) {
            statusCreate = 2; // Der Status 2 sperrt die Bearbeitung anderer Events, die nicht zur
            // Bearbeitung der Änderung des LoP-Eintrags gehören
            const tr_act = event.target.parentElement;
            const id_act = Number(tr_act.getAttribute('data-lop-id'));
            if (logEvent)
                console.log("id_act: ", id_act); // Debug
            // XMLHttpRequest aufsetzen und absenden
            const request = new XMLHttpRequest();
            // Request starten
            request.open('POST', 'read');
            request.setRequestHeader('Content-Type', 'application/json');
            request.send(JSON.stringify({
                "id_act": id_act
            }));
            request.onload = (event) => {
                // Eventhandler für das Lesen der aktuellen Tabellenzeile zum Ändern oder Löschen
                // vom Server
                if (request.status === 200) { // Erfolgreiche Rückgabe
                    const html_Change = request.response;
                    if (logEvent)
                        console.log("Ergebnis vom Server: ", html_Change);
                    if (command === "ändern")
                        tr_act.parentElement.innerHTML = html_Change;
                    else
                        tr_act.innerHTML = html_Change;
                }
                else { // Fehlermeldung vom Server
                    console.log("Fehler bei der Übertragung", request.status);
                    if (logEvent)
                        console.log("Fehler bei der Übertragung", request.status, "\n", event);
                }
            };
        }
    }
    else if (command === "loeschen") {
        // löschen --------------------------------------------------------------------------------
        /* Ein Element der LoP wird durch das Löschen an dieser Stelle nur deaktiviert
           (Status = 2) und nicht endgültig gelöscht (Status = 3).
        */
        if (logEvent)
            console.log("function  createUpdateDelete -> löschen"); // Debug
        if (logEventFull)
            console.log("löschen: ", event.target); // Debug
        // aktuelles Element ermitteln
        const id_act = Number(event.target.getAttribute('data-lop-id'));
        // XMLHttpRequest aufsetzen und absenden
        const request = new XMLHttpRequest();
        // Request starten
        request.open('POST', 'delete');
        request.setRequestHeader('Content-Type', 'application/json');
        request.send(JSON.stringify({
            "id_act": id_act
        }));
        request.onload = (event) => {
            // Eventhandler für das Lesen der aktuellen Tabellenzeile zum Ändern oder Löschen
            // vom Server
            if (request.status === 200) { // Erfolgreiche Rückgabe
                if (logEventFull)
                    console.log("Gelöscht: ");
                renderList();
            }
            else { // Fehlermeldung vom Server
                console.log("Fehler bei der Übertragung", request.status);
                if (logEvent)
                    console.log("Fehler bei der Übertragung", request.status, "\n", event);
            }
        };
    }
    else if (command === "aendern") {
        // ändern ---------------------------------------------------------------------------------
        if (statusCreate === 2) {
            // Das aktuelle Element der LoP wird entsprechend der Nutzereingabe geändert
            if (logEvent)
                console.log("function  createUpdateDelete -> ändern"); // Debug
            if (logEventFull)
                console.log("ändern: ", event.target); // Debug
            // Geänderte Daten aus HTML-Dokument übernehmen
            const td_actual = event.target.parentElement.parentElement;
            const current_task = td_actual.childNodes[0].value;
            const current_who = td_actual.previousSibling.childNodes[0].value;
            const current_where = td_actual.nextSibling.childNodes[0].value;
            const current_date = td_actual.nextSibling.nextSibling.childNodes[0].value;
            console.log("date: ", current_date, "where:", current_where);
            console.log("td_aktuell", td_actual);
            if (logEvent)
                console.log("ändern: ", current_who, current_task, current_where, current_date); // Debug
            // aktuelles Element ermitteln
            const id_act = Number(event.target.getAttribute('data-lop-id'));
            // XMLHttpRequest aufsetzen und absenden
            const request = new XMLHttpRequest();
            // Request starten
            request.open('POST', 'update');
            request.setRequestHeader('Content-Type', 'application/json');
            request.send(JSON.stringify({
                "id_act": id_act,
                "who": current_who,
                "item": current_task,
                "where": current_where,
                "date": current_date
            }));
            request.onload = (event) => {
                // Eventhandler das Lesen der aktuellen Tabelle vom Server
                if (request.status === 200) { // Erfolgreiche Rückgabe
                    renderList();
                }
                else { // Fehlermeldung vom Server
                    console.log("Fehler bei der Übertragung", request.status);
                    if (logEvent)
                        console.log("Fehler bei der Übertragung", request.status, "\n", event);
                }
            };
        }
    }
    else {
        // Clicks ins Nirgendwhere -------------------------------------------------------------------
        if (logEvent)
            console.log("function  createUpdateDelete -> ?"); // Debug
    }
}
function renderList() {
    /*
    * Ausgabe der aktuellen LoP und Abschluss ausstehender Nutzer-Interaktionen.
    * Alle Eingabefelder in der LoP-Tabelle werden gelöscht.
    */
    const table_body = document.getElementById("list-tbody");
    let html_LoP = "";
    // XMLHttpRequest aufsetzen und absenden ----------------------------------
    const request = new XMLHttpRequest();
    // Request starten
    request.open('GET', 'read');
    request.send();
    request.onload = (event) => {
        // Eventhandler für das Lesen der aktuellen Tabelle vom Server
        if (request.status === 200) { // Erfolgreiche Rückgabe
            html_LoP = request.response;
            if (logEventFull)
                console.log("Ergebnis vom Server: ", html_LoP);
            table_body.innerHTML = html_LoP;
            const lopCreateSave = document.getElementById("list-create-save");
            lopCreateSave.classList.remove("as-unsichtbar");
            lopCreateSave.classList.add("as-sichtbar");
            statusCreate = 0; // Der Status 0 gibt die Bearbeitung aller Events frei.
            // Die ausgegebene Tabelle im Browser entspricht jetzt dem aktuellen
            // Stand.
        }
        else { // Fehlermeldung vom Server
            console.log("Fehler bei der Übertragung", request.status);
            if (logEvent)
                console.log("Fehler bei der Übertragung", request.status, "\n", event);
        }
    };
}
// Callbacks - Eventlistener ---------------------------------------------------
document.addEventListener("DOMContentLoaded", () => {
    /* Warten bis der DOM des HTML-Dokuments aufgebaut ist. Danach wird die
       Funktionalität der Website gestartet und  die "Callbacks" initialisiert.
    */
    start();
    document.getElementById("eingabe-basedata").addEventListener("submit", (event) => {
        /* Nach der Eingabe des Bearbeiternamens wird die Tabelle aufgebaut
         */
        if (logEvent)
            console.log("eingabe-basedata; submit"); // Debug
        basedata(event);
    });
    document.getElementById("list-tbody").addEventListener("click", (event) => {
        /* Callback für die Buttons
           - "speichern" -> Erzeugen eines neuen Eintrags in der LoP anhand der Eingabedaten (CREATE)
           - "zurück" -> abbrechen der aktiven Aktion
           - "ändern" -> ändern eines ausgewählten Eintrags in der LoP anhand der Eingabedaten (UPDATE)
           - "löschen" -> löschen eines ausgewählten Eintrags (DELETE)
         */
        event.preventDefault();
        if (logEvent)
            console.log("lop-list-render; click"); // Debug
        if (logEventFull)
            console.log("llop-list-render; click", event); // Debug
        createUpdateDelete(event);
    });
    document.getElementById("list-tbody").addEventListener("submit", (event) => {
        event.preventDefault();
        createUpdateDelete(event);
    });
    document.getElementById("list-create-save").addEventListener("submit", (event) => {
        /* Callback für die Buttons
           - "neu" -> neuen Eintrag für die LoP abfragen
           - "sichern" -> aktuelle LoP auf dem Server sichern
         */
        if (logEvent)
            console.log("list-create-save; submit"); // Debug
        if (logEventFull)
            console.log("list-create-save; submit", event); // Debug
        item(event);
    });
});
//# sourceMappingURL=kiste.js.map